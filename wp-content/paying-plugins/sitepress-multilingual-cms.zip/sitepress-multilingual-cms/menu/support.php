
<div class="wrap">
    <div id="icon-wpml" class="icon32"><br /></div>
    <h2><?php _e('Support', 'sitepress') ?></h2>
<?php do_action('icl_support_admin_page'); ?>
</div>