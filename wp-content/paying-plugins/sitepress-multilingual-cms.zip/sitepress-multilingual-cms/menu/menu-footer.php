<?php
/*
<div class="updated message">
<h3 style="margin-bottom:0px;"><?php echo __('Need help?', 'sitepress')?></h3>
<p style="line-height:1.4em;"><?php printf(__("Purchase a <a%s>support subscription</a> and get help directly from WPML's developers. We will help you get the most out of WPML and customize it for your site.", 'sitepress'), 
    ' href="admin.php?page='.ICL_PLUGIN_FOLDER.'/menu/support.php"'); ?></p>
</div>
*/
?>


