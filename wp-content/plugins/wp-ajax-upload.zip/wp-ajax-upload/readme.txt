=== Alchemist Ajax Upload ===
Contributors: tandubhai
Donate link: http://tandukar.com/
Tags: wp-ajax, ajax upload
Requires at least: 3.5
Tested up to: 3.5.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Alchemist Ajax Upload is a wordpress plugin which allows you to upload image in front end.

== Description ==

This allows user to upload image at front-end. Add shortcode [AAIU] any where in post, page or in your custom form.
For theme insert the code ' echo do_shortcode('[AAIU theme="true"]');' in your theme.
AAIU settings allows you to:

*   set maximum file size
*   set image extension types
*   set maximum number of image

== Installation ==
* Upload the folder wp_ajax_image_upload  to the wp-content/plugins/ directory
* Activate the plugin through the 'Plugins' menu in WordPress
* Place shortcode [AAIU] in post, page or in your custom form anywhere you want.
* place the code ' echo do_shortcode('[AAIU theme="true"]'); ' to enable in theme.

== Changelog ==

= 1.1 =
* FIXED: upload button is not working when shortcode is added to theme.
