tinyMCE.addI18n('it.wordpress_form_manager_dlg',{
label:"Seleziona modulo",
desc:"Inserisci un modulo",
});