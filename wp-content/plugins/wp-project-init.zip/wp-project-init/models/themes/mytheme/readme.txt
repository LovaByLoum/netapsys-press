= mytheme =

* by  __WPI__THEME__AUTHOR__

== ABOUT mytheme ==