<?php
/*
 * fonctions personnalistion de l'interface admin
 * @package WordPress
 * @subpackage mytheme
 * @since mytheme __WPI__THEME__VERSION__
 * @author : __WPI__THEME__AUTHOR__
 */

add_action('admin_head','mytheme_custom_admin_head');
function mytheme_custom_admin_head(){
	?>
	<style>

	</style>
	
	<?php
}
