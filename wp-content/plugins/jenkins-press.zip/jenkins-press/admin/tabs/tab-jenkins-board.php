<?php
?>
<iframe src="http://ci01.mg.netapsys.fr:8090/jenkins/?output=embed"></iframe>