<?php
/*
* your script here
*/
echo 'script1 done.';
?>